from odoo import api, fields, models, _
    
 
class CustomerReport(models.Model):
    _inherit = 'res.partner'
    
    user_ids = fields.Many2many('res.users', string='Customer Access')
    
# class SaleOrder(models.Model):
#     _inherit = 'sale.order'
#     @api.multi
#     def _get_user(self):
#         res_user = self.env['res.users'].search([('id', '=', self._uid)])
#         re = res_user.has_group('sales_team.group_sale_manager')
#         for rec in self:
#             if re == True:
#                 print ("--------------------------xxxxxxxxxxxxx")
#                 self.sale_domain = True
#             else:
#                 self.sale_domain = False
#     sale_domain = fields.Boolean(string="check field",default=_get_user)
# 
#  
                
