# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
'name': 'Sale Rule',
'version': '1.1',
'website': 'https://www.devcomerp.com',
'category': '',
'sequence': 10,
'summary': 'Sale Rule',
'depends': [
    'base_setup',
    'base',
    'sale',
],
'description': "",
'data': [
     'views/customer_contact_view.xml',
   

],
'qweb': [],
'demo': [],
'test': [
],
'installable': True,
'auto_install': False,
'application': True,
}
